<P>
        <IMG align="left" src="images/logo1.png" width="8%" height="8%" border="0">
        <IMG align="right" src="images/logo1.png" width="8%" height="8%" border="0">
        
</P>

<?php



echo "<br />";
echo "<div align='center'><b><font face='segoe ui' size=\"7\" color='white'>MUNICIPALIDAD DE PUERTO CORTÉS</color></font></b></div>";
echo "<br />";
echo "<div align='center'><b><font face='segoe ui' size=\"5\" color='white'>CONTROL DE DOCUMENTACIÓN MUNICIPAL (CDM)</font></b></div>";
echo "<br />";
echo "<br />";

?>