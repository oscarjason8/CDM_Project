<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flexboxgrid/6.3.1/flexboxgrid.min.css" type="text/css" >
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Crete+Round&display=swap" rel="stylesheet">
<div class="container">
  <div class="row" style="margin-bottom: 15px;">
    <div class="col-xs-12">
      <div class="col-md-2 col-xs-12 center-xs">
        <img src="images/logo1.png" style="width: 120px; height: 120px;">
      </div>
      <div class="col-md-10 col-xs-12 center-xs">
        <h1 style="font-family: 'Crete Round', serif;">MUNICIPALIDAD DE PUERTO CORTÉS</h1>
      </div>
    </div>
  </div>
</div>