<P align="center"><BR></P> 
<TABLE align="center" width="95%" border="1" cellspacing="1" cellpadding="1">
  <TBODY>
  <TR>
    <TD>&nbsp;Municipalidad de Puerto Cortés &copy; 2020</TD>
    <TD>
      <DIV align="center"><a href="https://www.ampuertocortes.hn" target="_blank">www.ampuertocortes.hn</a></DIV></TD>
    <TD>
      <DIV align="right">Desarrollo e Innovación               
      Tecnológica versión 1.0&nbsp;</DIV>
    </TD>
  </TR>
  <TR>
    <TD colspan="3" align="center">
<strong>ODS-9 metas 9.4, 9.5, 9.6, 9.7 y 9.8</strong>; POA 2019 incisos 4, 5, 8, 9, 10 y 11; CD resultados 1 y 2
    </TD>
  </TR>
  </TBODY>
</TABLE>